# .Faça um programa que calcule as potências de 2 até um determinado número
n = int(input("Digite até que número determinado: "))

for i in range(n+1):
    potencia = 2 ** i
    if potencia > n:
        print (f"2 elevado à {i} = {potencia}")