#Faça um programa que receba 5 números do usuário e retorne a média aritmética. 
n1 = int (input ("Insira o número: "))
n2 = int (input ("Insira o número: "))
n3 = int (input ("Insira o número: "))
n4 = int (input ("Insira o número: "))
n5 = int (input ("Insira o número: "))
media = (n1+n2+n3+n4+n5)/5
print (f"A média é: {media}")