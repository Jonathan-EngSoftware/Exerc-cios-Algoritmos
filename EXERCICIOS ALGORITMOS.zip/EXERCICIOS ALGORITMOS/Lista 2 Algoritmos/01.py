#1.Faça um programa que imprima os números de 1 a 10
#Use o commando Para (for)
for _ in range (1,11):
    print (_)

#Use o comando enquanto (while)
i = 1
while i <= 10:
    print (i)
    i = i+1