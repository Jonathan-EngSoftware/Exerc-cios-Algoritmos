#Faça um programa que receba um número e determine se ele é primo ou não.
n = int (input ("Insira o número: "))
if n == 2:
    print (f"O número {n} é primo")
elif n % 2 == 0:
    print (f"O número {n} não é primo")

else:
    print (f"O número {n} é primo")