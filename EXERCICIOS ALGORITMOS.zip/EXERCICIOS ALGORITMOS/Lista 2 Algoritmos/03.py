#Faça um programa que imprima a tabuada de um número fornecido pelo usuário.
n = int (input ("Insira o número:"))
for i in range (1, 11):
    tabuada = n*i
    print (tabuada)