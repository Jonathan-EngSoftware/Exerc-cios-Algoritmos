# Escreva um programa que leia dois números inteiros do usuário e
# exiba na tela o maior deles.

n1 = int(input("entre c um valor: "))  
n2 = int(input("entre c outro valor: "))
if n1 > n2:
    print("o maior é: ", n1)
else:
    print("o maior é: ",n2)