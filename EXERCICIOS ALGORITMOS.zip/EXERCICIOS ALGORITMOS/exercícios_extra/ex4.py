# Escreva um programa que leia o valor do salário de 
# um funcionário e 
# calcule o novo salário com um aumento de 15%.
salario = float(input("digite salario"))
# porcentagem = 15/100
# aumento = salario * porcentagem
# novosalario = salario + aumento
novosalario = salario * 1.15
print("o novo salario é: ",novosalario)

