#5. Faça um programa que leia dois números e exiba o maior deles.
n1 = int (input ("Insira o primeiro número:"))
n2 = int (input ("Insira o segundo número:"))
if n1 > n2:
    print(f"O {n1} é maior")
else:
    print (f"O {n2} é maior")