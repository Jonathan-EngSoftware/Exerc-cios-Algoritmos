#3. Faça um programa que leia um número real e exiba sua parte inteira.
n = float (input ("Insira o número real: "))
inteiro = int (n)
print (f"A parte inteira de {n} é: {inteiro}")