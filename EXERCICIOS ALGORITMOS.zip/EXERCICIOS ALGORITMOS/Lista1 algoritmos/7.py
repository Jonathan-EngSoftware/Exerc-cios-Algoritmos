#7. Faça um programa que leia um número e exiba seu dobro e o triplo .
n = int (input ("Insira o número: "))
dobro = n*2
triplo = n*3
print (f"O dobro de {n} é: {dobro}\nO triplo de {n} é: {triplo}")