# 1. Faça um programa que calcule a média aritmética de três números
n1 = float (input ("Insira o n1: "))
n2 = float (input ("Insira o n2: "))
n3 = float (input ("Insira o n3: "))
media = (n1+n2+n3)/3
print (f"A média é {media}")