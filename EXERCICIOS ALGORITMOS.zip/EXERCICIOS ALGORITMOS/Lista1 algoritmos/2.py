# 2. Faça um programa que leia um número inteiro e exiba seu antecessor e sucessor
n = int (input ("Insira um número inteiro: "))
ant = n-1
suc = n+1
print (f"O número {n}, tem como antecessor: {ant} e o sucessor é: {suc}")