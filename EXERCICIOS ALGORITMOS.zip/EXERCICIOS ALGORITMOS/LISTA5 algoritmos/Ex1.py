#Faça um programa que tendo como dados de entrada a distância total (em km) percorrida por um automóvel e a quantidade de combustível (em litros)
#consumida para percorrê-la, calcule e imprima o consumo médio decombustível..
distancia = int (input ("Distância percorrida: "))
combustivel = int(input ("Combustível consumido em litros: "))
media = distancia/combustivel
print (f"O consumo médio é: {media} km/l")


