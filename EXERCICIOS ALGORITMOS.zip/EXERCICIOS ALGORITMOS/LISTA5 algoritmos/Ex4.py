#Faça um Programa que peça o raio de um círculo, calcule e mostre sua área
raio = int (input("Raio do círculo: "))
pi = 3.14
media = pi*raio**2
print (f"A área do círculo é: {media} cm")