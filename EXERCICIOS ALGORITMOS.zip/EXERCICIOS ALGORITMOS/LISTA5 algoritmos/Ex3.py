#Faça um programa que converta de metros para centímetros
m = float (input("Insira a metragem: "))
cm = m*100
print (f"{m} metros são: {cm} centímetros")