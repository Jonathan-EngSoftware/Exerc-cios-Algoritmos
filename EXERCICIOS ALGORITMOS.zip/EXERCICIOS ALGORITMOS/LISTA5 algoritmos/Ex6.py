# Faça um Programa que peça a temperatura em graus Fahrenheit, transforme e mostre a temperatura em graus Celsius.
temp = int (input ("Temperatura em Fahrenheit: "))
cel = (temp - 32)* 5/9
print (temp," °F são", round(cel,0), " °C")
