#. Faça um Programa que pergunte quanto você ganha por hora e o número de horas trabalhadas no mês.
#Calcule e mostre o total do seu salário no referido mês
pag = float (input ("Salário por hora trabalhada: "))
hor = int (input ("Horas trabalhadas no mês: "))
sal = pag*hor
print (f"Seu salário esse mês é de: {sal} R$")