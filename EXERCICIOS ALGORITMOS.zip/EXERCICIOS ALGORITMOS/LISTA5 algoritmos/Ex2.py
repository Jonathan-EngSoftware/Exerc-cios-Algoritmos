#Faça um programa que exibia todos os números pares de um a 100
for i in range (2, 101, 2):
    print (i)
    