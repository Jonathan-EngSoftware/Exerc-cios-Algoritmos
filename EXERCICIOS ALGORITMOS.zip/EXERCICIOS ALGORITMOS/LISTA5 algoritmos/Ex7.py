#Faça um Programa que peça a temperatura em graus Celsius, transforme e mostre em graus Fahrenheit
temp = int (input ("Temperatura em Celsius: "))
fa = (temp * 9/5) + 32
print (temp," °C são", round(fa, 0), " °F")
