#1.Indique se as alternativas são corretas ou não:
#a) Uma variável é uma posição na memória do computador que pode receber diversos valores ao longo da execução do programa.
#b) Uma mesma variável pode receber diferentes 7pos de valores (alfanuméricos, numéricos, lógicos) durante a execução do programa
#c) Variáveis de 7pos diferentes podem ser usadas para troca de valores, com uso de conversão de 7pos.
#d) Não é permi7do u7lizar duas variáveis com o mesmo nome.
#e) Cada variável u7lizada pode ser acessada em qualquer parte do programa.
#f) Quando uma expressão aritmé7ca apresenta parênteses aninhados, sempre o conjunto mais interno é avaliado primeiro
#g) A operação aritmé7ca soma é a única com o mesmo nível de precedência da mul7plicação.
#h) Duas variáveis definidas como “var” e “Var” são consideradas como idên7cas
#i) Os operadores ( * + - / ) tem todos a mesma precedência.

'a) verdadeiro'
'b) verdadeiro'
'c) verdadeiro'
'd) Falso'
'e) Falso'
'f) Verdadeiro'
'g) Falso'
'h) Falso'
'i) Falso'